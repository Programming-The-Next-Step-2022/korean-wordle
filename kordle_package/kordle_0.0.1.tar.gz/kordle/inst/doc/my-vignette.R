## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup,include=F----------------------------------------------------------
library(kordle)
source('C:/Users/Emilija/Desktop/r_dir/kordle/kordle/wordlist.R',
         encoding = 'utf-8')
Sys.setlocale("LC_ALL", "Korean")

## -----------------------------------------------------------------------------
target_word <- sample(wordlist$hangeul,1)
target_word

## -----------------------------------------------------------------------------
wordlist[wordlist$hangeul == target_word,c(1:6)]
toString(wordlist[wordlist$hangeul == target_word,8])

## ----eval=F-------------------------------------------------------------------
#  compare_word(
#      target = target_word,
#      guess = guess_word
#  )
#  compare_word('친구','단근')
#  #>[1] "nope"    "nope"    "correct" "correct" "nope"    "close"

## ----eval=F-------------------------------------------------------------------
#  output_word(
#      target = target_word,
#      guess = guess_word,
#      result = compare_word(target_word,guess_word)
#  )
#  #>[1] " \u3137  \u314f [\u3134][\u3131] \u3161  \u3134 "

## ----eval=F-------------------------------------------------------------------
#  translate_word(
#    guess = guess_word
#  )
#  
#  translate_word('단근')
#  #>[1] "carrot"

