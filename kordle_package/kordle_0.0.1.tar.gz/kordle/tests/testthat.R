library(testthat)
library(kordle)

test_check("kordle")
