


wordlist <- readr::read_csv('korean.csv', col_names = T,
                            locale = readr::locale(date_names = 'ko', encoding = 'UTF-8'))
